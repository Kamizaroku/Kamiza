<?php
require __DIR__ . '/vendor/autoload.php';

use Symfony\Component\Mailer\Mailer;
use Symfony\Component\Mailer\Transport;
use Symfony\Component\Mime\Email;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    $senderName  = $_POST['sender_name'];
    $fromEmail   = $_POST['from_email'];
    $appPassword = $_POST['app_password'];
    $subject     = $_POST['subject'];
    $message     = $_POST['message'];

    $recipients = [];
    if (!empty($_FILES['numbers_file']['tmp_name'])) {
        $recipients = file($_FILES['numbers_file']['tmp_name'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    }

    $totalRecipients = count($recipients);
    $dsn = "smtp://jongeemma4@gmail.com:jkvswjfcpfpzewzv@smtp.gmail.com:587";
    $transport = Transport::fromDsn($dsn);
    $mailer    = new Mailer($transport);

    $sentCount = 0;
    foreach ($recipients as $recipient) {
        $email = (new Email())
            ->from("$senderName <$fromEmail>")
            ->to($recipient)
            ->subject($subject)
            ->html("<div style='font-family: Arial, sans-serif; padding:20px; background:#f9f9f9; border-radius:10px;'>
                        <h2 style='color:#ff6600;'>$subject</h2>
                        <p style='color:#333;'>$message</p>
                    </div>");

        try {
            $mailer->send($email);
            $sentCount++;
            $progress = round(($sentCount / $totalRecipients) * 100);

            echo json_encode(['progress' => $progress, 'sent' => $sentCount, 'total' => $totalRecipients]) . "\n";
            flush();
            ob_flush();
            sleep(3); // slow down so progress is visible
        } catch (Exception $e) {
            echo json_encode(['error' => "Failed to send to $recipient: {$e->getMessage()}"]) . "\n";
            flush();
            ob_flush();
        }
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Kamiza Mailer</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
            background: url('matrix.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            background: rgba(0,0,0,0.85);
            padding: 30px;
            margin: 50px auto;
            border-radius: 15px;
            max-width: 500px;
            box-shadow: 0 0 20px rgba(0,0,0,0.6);
        }
        h1 {
            color: #ff6600;
        }
        label {
            font-weight: bold;
            display: block;
            text-align: left;
            margin-top: 10px;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: none;
        }
        input[type="submit"] {
            background-color: #ff6600;
            color: white;
            font-weight: bold;
            cursor: pointer;
            margin-top: 15px;
        }
        input[type="submit"]:hover {
            background-color: #e65c00;
        }
        .progress-container {
            background: #444;
            border-radius: 10px;
            margin-top: 20px;
            height: 20px;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }
        .progress-bar {
            height: 100%;
            width: 0;
            background-color: #ff6600;
            border-radius: 10px;
            transition: width 0.3s ease;
        }
        .status {
            margin-top: 10px;
            font-size: 14px;
            color: #ffcc00;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Kamiza Mailer 1.0</h1>
        <form id="mailerForm" enctype="multipart/form-data">
            <label>Sender Name:</label>
            <input type="text" name="sender_name" placeholder="ENTER CUSTOM NAME" required>

            <label>Your Gmail Address:</label>
            <input type="email" name="from_email" placeholder="you@gmail.com" required>

            <label>Your App Password:</label>
            <input type="password" name="app_password" required>

            <label>Recipient List (.txt):</label>
            <input type="file" name="numbers_file" accept=".txt" required>

            <label>Subject:</label>
            <input type="text" name="subject" required>

            <label>Message:</label>
            <textarea name="message" rows="5" required></textarea>

            <input type="submit" value="Send Message">
        </form>

        <div class="progress-container" style="display:none;">
            <div class="progress-bar" id="progressBar"></div>
        </div>
        <div class="status" id="status"></div>
    </div>

    <script>
        const form = document.getElementById('mailerForm');
        const progressBar = document.getElementById('progressBar');
        const progressContainer = document.querySelector('.progress-container');
        const status = document.getElementById('status');

        form.addEventListener('submit', e => {
            e.preventDefault();

            const formData = new FormData(form);
            formData.append('ajax', '1');

            progressContainer.style.display = 'block';
            progressBar.style.width = '0%';
            status.textContent = 'Starting...';

            fetch('', {
                method: 'POST',
                body: formData
            }).then(response => {
                if (!response.body) throw new Error('ReadableStream not supported');

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';

                function read() {
                    return reader.read().then(({ done, value }) => {
                        if (done) {
                            status.textContent += ' Done! Reloading page...';
                            setTimeout(() => {
                                location.reload();
                            }, 2000);
                            return;
                        }
                        buffer += decoder.decode(value, { stream: true });

                        let lines = buffer.split("\n");
                        buffer = lines.pop();

                        for (const line of lines) {
                            if (line.trim() === '') continue;
                            try {
                                const data = JSON.parse(line);
                                if (data.progress !== undefined) {
                                    progressBar.style.width = data.progress + '%';
                                    status.textContent = `Sent ${data.sent} of ${data.total} emails...`;
                                }
                                if (data.error) {
                                    status.textContent = `Error: ${data.error}`;
                                }
                            } catch(e) {
                                console.error('Invalid JSON', e);
                            }
                        }
                        return read();
                    });
                }
                return read();
            }).catch(err => {
                status.textContent = 'Error: ' + err.message;
            });
        });
    </script>
</body>
</html>

